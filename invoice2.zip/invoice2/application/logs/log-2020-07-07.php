<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-07 12:15:47 --> Could not find the language line "cannot_connect_database_server"
ERROR - 2020-07-07 12:15:47 --> Could not find the language line "cannot_connect_database_server"
ERROR - 2020-07-07 14:54:42 --> 404 Page Not Found: /index
ERROR - 2020-07-07 14:54:48 --> 404 Page Not Found: /index
ERROR - 2020-07-07 14:55:00 --> 404 Page Not Found: /index
ERROR - 2020-07-07 14:55:55 --> 404 Page Not Found: /index
ERROR - 2020-07-07 14:55:57 --> 404 Page Not Found: /index
ERROR - 2020-07-07 14:56:45 --> 404 Page Not Found: /index
ERROR - 2020-07-07 14:56:46 --> 404 Page Not Found: /index
ERROR - 2020-07-07 14:57:00 --> 404 Page Not Found: /index
ERROR - 2020-07-07 18:13:29 --> 404 Page Not Found: /index
ERROR - 2020-07-07 18:13:32 --> 404 Page Not Found: /index
